
<!DOCTYPE html>
<html>
    <head>
        <title>Fudma Journal of Research, Educational Psychology and Counselling</title>
        <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
   <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/logg.jpg" rel="icon">
  <link href="assets/img/logg.jpg" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="css/web_style.css" rel="stylesheet">
  <!-- sweetAleart here -->
  <script src="https://cdn.bootcss.com/jquery/3.3.1/jquery.js"></script>
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
  <link href="css/web_style.css" rel="stylesheet">
           
    </head>
        <!-- main header of the page  -->
        <!-- <header> -->
        <body class="body">
        <?php 
                 include_once('includes/Db_Connect.php');
        ?>
              
            <?php 
                    include 'includes/submit.php';
            ?>
        <!-- </header> -->
            <!-- navigation links  -->
       
            <!-- section starts from here  -->
        <section class="calline">
                 A PUBLICATION OF FUJREPAC 2024
        </section>
        <!-- journal article section     -->
        <article>
                 <!-- style="background-color: white; height: 100%; padding:; width: 70%; font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', 'Geneva', Verdana, sans-serif; font-size: 14px; border-radius: 6px, 8px, 12px solid black; clear: both;"> -->
       <center> <h2 style="font-size: 16px; color: radial-gradient(circle, rgba(0,0,0,1) 0%, rgba(48,186,65,0.9654061453683036) 83%);"><u>INSTRUCTIONS TO CONTRIBUTORS</u> </h1></center><br>
        <p align="justify"> </p>  
        
        <ol type="circle" align="justify">
                <li>Journal articles are accepted for publication by this journal on the understanding that they have not
                been published in any other outlet and are currently not being considered for publication elsewhere. </li>
                <li>Research-based articles are expected to be original works that include: an introduction (to include
literature review, theoretical/conceptual framework, and problem statement), purpose, research
questions and or hypotheses, methodology, results of data analysis, discussion, conclusion,
recommendations, and list of references. </li>
                <li>Expository essays/Position papers should be structured logically and may follow the pattern: title,
                abstract, introduction, main body, conclusion, recommendation, and references. </li>
                <li>The manuscript should normally conform to the style of the 7th edition of the Publication Manual
                of the American Psychological Association (APA).</li>
                <li>It should not exceed a maximum of 12 pages, inclusive of the title page and the references list. It
should include a cover page containing the title of the manuscript, the name(s), affiliation(s), phone
numbers, and e-mail addresses of the author(s). </li> 
                <li>An Abstract of between 150 to 200 words (single-line spacing) should follow the title closely on
                this page and should be followed by three to five keywords for indexing purposes.      </li>
                <li>Manuscripts should be formatted as MS Word document using Times New Roman characters (12-
point font size). It should be double line spacing while the margins should be one inch on all sides
except the left side with 1.5 inches. </li>
                <li>Tables and figures should be marked with Arabic numerals and should not have vertical lines. All
                figures, diagrams, and charts should be presented in compliance with 7th edition APA styles. </li>
                <li>The soft copy of the article prepared in Microsoft Word should be sent to the Managing Editor via
                email at fujrepac@fudutsinma.edu.ng or fujrepac@gmail.com </li>
                <li>Submission of an article is to be accompanied by a non-refundable assessment fee of five Thousand
Naira (N5,000.00) or the equivalence in the currency of your country payable to: Bank: United
Bank for Africa (UBA), Account Name: Fudma Journal of Research, Educational Psychology and
Counselling; Account No: 2311581782 (Note: A copy of the proof of payment should also be sent
to the above email address); </li> 
                <li>Author(s) whose articles are accepted for publication will be requested to pay publication fee of
                twenty thousand naira (N20, 000.00) or the equivalence in the currency of your country. </li>
                <li>Published articles will be uploaded on the Journal website: www.fujrepac.com </li> 
                                
        </ol> 
        <p align="justify" style="font-size: 16px;">All correspondences to: Prof. A. A. Bagudu (08033802836)<br> Editor-in-Chief <br> Email: fujrepac@gmail.com</b> </p>  

        </article>
        <!-- this is aside  -->
        <aside>
        <center><h5>DISCLAIMER</h5> </center>
       <p align="justify">
          <div>Every Author is solely responsible for the views and styles expressed in the articles
published in this Journal. The views are not necessarily shared by reviewers, the Editorial Board,
Editorial Advisory Board, the Department of Educational Psychology and Counselling and Federal
University Dutsin-Ma, Katsina State.</div> </p>

<h5>All Right Reserve</h5>
       <marquee> <p align="justify">No part of this publication may be reproduced, stored or transmitted or disseminated in any
form or by any means without prior written permission from the Department of Educational
Psychology and Counselling, Federal University, Dutsin-Ma, Nigeria. Consent is hereby
given to the contributors to copy their own articles from the Journal for any scholarly or
academic purpose of their own.</p></marquee>
 <center><div class="contena">

 Research for Human and National Development
 </div>  </center>  
        <center> <h2 style="font-size: 16px;"><b>Current Issues</b></h2></center><br>
        
           <div> <a href="current_issues"> Vol. 2 No 2 (June 2024): Fujrepac<a></div><br>
        
  <button type="submit" class="btn app-btn-primary" name="submit" style="background:radial-gradient(circle, rgba(0,0,0,1) 0%, rgba(48,186,65,0.9654061453683036) 83%); color: hwb(0 100% 0%);"><a href="login" style="color: white;">Submit Your Articles</a></button>
 </aside>
       
        
     <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

        </body>
        <!-- footer starts here -->
        <footer class="myfooter">
 <?php 
        include_once('includes/footer.php')
 ?>
        </footer>
        
</html>


<?php
session_start();
if(!isset($_SESSION['author']))
{
	header("location:login");
} ?>
<!DOCTYPE html>
<html>
    <head>
        <title>Fudma Journal of Research, Educational Psychology and Counselling</title>
        <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
   <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/logg.jpg" rel="icon">
  <link href="assets/img/logg.jpg" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="css/web_style.css" rel="stylesheet">
  <!-- sweetAleart here -->
  <script src="https://cdn.bootcss.com/jquery/3.3.1/jquery.js"></script>
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
  <link href="css/web_style.css" rel="stylesheet">
           
    </head>
        <!-- main header of the page  -->
        <!-- <header> -->
        <body class="body">
                <?php 
                        include_once('includes/Db_Connect.php');
                ?>
              
            <?php 
                    include_once('includes/submit.php');
            ?>
        <!-- </header> -->
            <!-- navigation links  -->
       
            <!-- section starts from here  -->
        <section class="calline">
                 <!-- style="background-color: rgb(173, 7, 7); padding: 2px; color: white; text-align: center;font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', 'Geneva', Verdana, sans-serif; font-size: 14px;"> -->
               A PUBLICATION OF FUJREPAC 2024
        </section>
        <!-- journal article section     -->
        <article>
                 <!-- style="background-color: white; height: 100%; padding:; width: 70%; font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', 'Geneva', Verdana, sans-serif; font-size: 14px; border-radius: 6px, 8px, 12px solid black; clear: both;"> -->
       <center> <h1 style="font-size: 16px; color: red;"><b><u>INSTRUCTIONS TO CONTRIBUTORS</u> </b></h1></center><br>
        <p align="justify"> </p>  
        
        <ol type="circle">
        <li>Journal articles are accepted for publication by this journal on the understanding that they have not
                been published in any other outlet and are currently not being considered for publication elsewhere. </li>
                <li>Research-based articles are expected to be original works that include: an introduction (to include
literature review, theoretical/conceptual framework, and problem statement), purpose, research
questions and or hypotheses, methodology, results of data analysis, discussion, conclusion,
recommendations, and list of references. </li>
                <li>Expository essays/Position papers should be structured logically and may follow the pattern: title,
                abstract, introduction, main body, conclusion, recommendation, and references. </li>
                <li>The manuscript should normally conform to the style of the 7th edition of the Publication Manual
                of the American Psychological Association (APA).</li>
                <li>It should not exceed a maximum of 12 pages, inclusive of the title page and the references list. It
should include a cover page containing the title of the manuscript, the name(s), affiliation(s), phone
numbers, and e-mail addresses of the author(s). </li> 
                <li>An Abstract of between 150 to 200 words (single-line spacing) should follow the title closely on
                this page and should be followed by three to five keywords for indexing purposes.      </li>
                <li>Manuscripts should be formatted as MS Word document using Times New Roman characters (12-
point font size). It should be double line spacing while the margins should be one inch on all sides
except the left side with 1.5 inches. </li>
                <li>Tables and figures should be marked with Arabic numerals and should not have vertical lines. All
                figures, diagrams, and charts should be presented in compliance with 7th edition APA styles. </li>
                <li>The soft copy of the article prepared in Microsoft Word should be sent to the Managing Editor via
                email at fujrepac@fudutsinma.edu.ng or fujrepac@gmail.com </li>
                <li>Submission of an article is to be accompanied by a non-refundable assessment fee of five Thousand
Naira (N5,000.00) or the equivalence in the currency of your country payable to: Bank: United
Bank for Africa (UBA), Account Name: Fudma Journal of Research, Educational Psychology and
Counselling; Account No: 2311581782 (Note: A copy of the proof of payment should also be sent
to the above email address); </li> 
                <li>Author(s) whose articles are accepted for publication will be requested to pay publication fee of
                twenty thousand naira (N20, 000.00) or the equivalence in the currency of your country. </li>
                <li>Published articles will be uploaded on the Journal website: www.fujrepac.com </li> 
                                
                
        </ol> 
        <p align="justify" style="font-size: 16px;">All correspondences to: Dr. S.O. Olomola (+2348062297046), <br> Prof. M. U. Sanda, Dr. S. E. Nnamdi and Dr. A. Y. Salisu <br> Email: fudmajem@gmail.com </p>  

        </article>
        <!-- this is aside  -->
        <aside>
                
           
        <div class="app-wrapper">
	    
	    <div class="app-content pt-3 p-md-3 p-lg-4">
		    <div class="container-xl">			    
			    <h1 class="app-page-title">Articles Submission Page</h1>
			    <hr class="mb-4">
                <div class="row g-4 settings-section">
	                <div class="col-12 col-md-12">
		                <div class="app-card app-card-settings shadow-sm p-4">
						    
						    <div class="app-card-body">
							    <form class="settings-form" action="" method="post" enctype="multipart/form-data">
                                <div class="mb-3">
									    <label for="setting-input-3" class="form-label" style="float:left;">Volume Type *</label>
									    <input type="text" class="form-control" id="setting-input-3" name="volume" placeholder="e.g Vol 1, Vol 2" required>
										</div>
                                     <div class="mb-3">
									    <label for="setting-input-3" class="form-label" style="float:left;">Title *</label>
									    <input type="text" class="form-control" id="setting-input-3" name="title" placeholder="" required>
										</div>
                                        <div class="mb-3">
									    <label for="setting-input-3" class="form-label" style="float:left;">Upload File *</label>
									    <input type="file" class="form-control" id="setting-input-3" name="pdfile" placeholder="" required>
										</div>
                                        <div class="mb-3"> 
									    <label for="setting-input-3" class="form-label" style="float:left;">Author Name</label> 
									    <input type="text" class="form-control" id="setting-input-3" name="author" placeholder="" required>
										</div>
								    <div class="mb-3">
									    <label for="setting-input-2" class="form-label" style="float:left;">Articles Area *</label>
									    <select class="form-control" id="setting-input-3" name="area" required>
											<option value="" disabled selected>Select Area</option>
											<option value="Educational Administration/Management">Educational Administration/Management </option>
                                            <option value="Educational planning">Educational planning</option>
                                            <option value="Business education">Business education</option>
                                            <option value="Administration of vocational Education ">Administration of vocational Education </option>
                                            <option value="Administration of Distance Education">Administration of Distance Education</option> 
                                            <option value="Administration of Adult education">Administration of Adult education</option>
                                            <option value="Administration Normadic Education">Administration Normadic Education</option>
                                            <option value="Administration Universal Basic Education">Administration Universal Basic Education</option>
                                            <option value="Administration of private schools">Administration of private schools </option>
                                            <option value="ICT in Education">ICT in Education</option> 
                                            <option value="Policy formulation and Implementation">Policy formulation and Implementation </option>
                                            <option value="Pre-primary Education">Pre-primary Education</option> 
                                            <option value="Primary education">Primary education </option> 
                                            <option value="Secondary education">Secondary education </option>
                                            <option value="Tertiary Education">Tertiary Education </option>
											</select></div>
                                            <div class="mb-3"> 
									    <label for="setting-input-3" class="form-label" style="float:left;">Page Number</label> 
									    <input type="text" class="form-control" id="setting-input-3" name="page" placeholder="" required>
										</div>
										 <div class="mb-3"> 
									    <label for="setting-input-3" class="form-label" style="float:left;">Published Date</label> 
									    <input type="date" class="form-control" id="setting-input-3" name="pubdate" placeholder="" required>
										</div>
                                        <div class="mb-3">
									    <label for="setting-input-3" class="form-label" style="float:left;">Approved Date</label>
									    <input type="date" class="form-control" id="setting-input-3" name="appdate" placeholder="" required>
										</div>
                                        <div class="mb-3">
									    <!-- <label for="setting-input-3" class="form-label" style="float:left;">Contact Address *</label> -->
									    <input type="number" class="form-control" id="setting-input-3" name="authorId" value="" hidden>
										</div>
                                        <div class="mb-3">
									    <!-- <label for="setting-input-3" class="form-label" style="float:left;">Institution Affiliation *</label> -->
									    <input type="text" class="form-control" id="setting-input-3" name="authorname" value="" hidden>
										</div>
                                        
										<button type="submit" class="btn app-btn-primary" name="submit" style="background-color:rgb(173, 7, 7); color: hwb(0 100% 0%)">Submit Now</button>
                                        <button type="submit" class="btn app-btn-primary" name="submit" style="background-color:rgb(173, 7, 7); color: hwb(0 100% 0%)"><a href="login" style="color: white;">End Submission</a></button>
                                        <?php
$err = "";

if(isset($_POST['submit']) && isset($_FILES['pdfile'])){
    $vol=mysqli_real_escape_string($con, $_POST['volume']);
    $title=mysqli_real_escape_string($con, $_POST['title']);
	$pdfile_name = $_FILES['pdfile']['name'];
	$pdfile_size = $_FILES['pdfile']['size'];
	$pdfile_type= $_FILES['pdfile']['type'];
	$pdfile_tmp = $_FILES ['pdfile']['tmp_name'];
	$pdfile_error = $_FILES['pdfile']['error'];

	//VALIDATION SECTION
	if($pdfile_size>2000000){
		$em = "You Can upload file less than 2MB";
		header("Location: upload.php");
	}
	$file_ext = pathinfo($pdfile_name, PATHINFO_EXTENSION);
	$file_ext_lc = strtolower($file_ext);

	$allowed_exts = array("doc", "docx", "pdf");

	// echo $file_ext;

	if(!in_array($file_ext_lc, $allowed_exts)){
		$err = "File type not allowed.";
	    }
        else{
		if($pdfile_error===0){
		$upload_path = "uploaded_articles/";
		$new_pdfile_name = uniqid("Fudmajem",true).".".$file_ext_lc;
		move_uploaded_file($pdfile_tmp, $upload_path.$new_pdfile_name);
        $auth=mysqli_real_escape_string($con, $_POST['author']);
        $category=mysqli_real_escape_string($con, $_POST['area']);
        $page=mysqli_real_escape_string($con, $_POST['page']);
        $pubdate=mysqli_real_escape_string($con, $_POST['pubdate']);
        $appdate=mysqli_real_escape_string($con, $_POST['appdate']);

		$sql = "INSERT INTO submission  ( volume, title, mainfile, author_name, category, page_no, published_date, approved_date) VALUES('$vol', '$title','$new_pdfile_name', '$auth', '$category', '$page','$pubdate', '$appdate')";
		$result = mysqli_query($con, $sql);
		if($result){
					//$em = "File Uploaded Successful...";
                    echo "<script>alert('Congarts! Your Articles Have Been Submitted Successfully')
		
		        </script>"; 
				}
                else{
					$em = "Uknown Error Occured.";
				}
	}
	}

}

?>
							    </form>
						    </div><!--//app-card-body-->
						    
						</div><!--//app-card-->
	                </div>
                </div><!--//row-->
                <hr class="my-4">
		    </div><!--//container-fluid-->
	    </div><!--//app-content-->
        </aside>
        <body class="body">
        
     <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

        </body>
        <!-- footer starts here -->
        <footer class="myfooter">
 <?php 
        include_once('includes/footer.php');
 ?>
        </footer>
        
</html>

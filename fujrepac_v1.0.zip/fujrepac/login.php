
<!DOCTYPE html>
<html>
    <head>
        <title>Fudma Journal of Research, Educational Psychology and Counselling</title>
        <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
   <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/logo.png" rel="icon">
  <link href="assets/img/logo.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="css/web_style.css" rel="stylesheet">
  <!-- sweetAleart here -->
  <script src="https://cdn.bootcss.com/jquery/3.3.1/jquery.js"></script>
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
  <link rel="stylesheet" href="css/web_style.css">
       
    </head>
        <!-- main header of the page  -->
        <!-- <header> -->
        <body class="body">
            <?php 
                include_once('includes/Db_Connect.php');
                
if(isset($_POST['signnap']))
    {		
		$login_id= mysqli_real_escape_string($con, $_POST['email']);
		$password= mysqli_real_escape_string($con, $_POST['password']);
		$query=mysqli_query($con, "select * from author where email='$login_id'");
		$finded_q=mysqli_fetch_array($query);
		if(mysqli_num_rows($query) > 0 && password_verify($password, $finded_q['password'])) 
		{
			// $user_id=$finded_q['staffid'];
			// $user_name=$finded_q['staff_name'];
			// $insert_log=mysqli_query($con, "insert into user_action (user_id, user_name, action_performed) values('$user_id', '$user_name', 'Logged in')");
			session_start();
			$_SESSION['author'] = $finded_q['author_Id'];
			$_SESSION['name'] = $finded_q['author_name'];
			$_SESSION['posting'] = $finded_q['status'];
			 if($_SESSION['posting'] =='active'){

                header("location:submission_page");
             }
             else{
                echo "<script>alert('Your Account is currently Inactive Please Contac Admin!')</script> ";
             }
		}
		else
		{
			echo "<script>alert('Incorrect Login Details')</script> ";
		}
}


?>
            
            <?php 
                    include_once('includes/reg.php');
            ?>
        <!-- </header> -->
            <!-- navigation links  -->
       
            <!-- section starts from here  -->
        <section class="calline">
            A PUBLICATION OF FUJREPAC 2024
        </section>
        <!-- journal article section     -->
        <article>
             <!-- style="background-color: white; height: 100%; padding:; width: 70%; font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', 'Geneva', Verdana, sans-serif; font-size: 14px; border-radius: 6px, 8px, 12px solid black; clear: both;"> -->
             <center> <h1 style="font-size: 16px; color: red;"><u>INSTRUCTIONS FOR REGISTRATION</u> </h1></center><br>
             <p align="justify"><ol type="circle">
             <li>Journal articles are accepted for publication by this journal on the understanding that they have not
                been published in any other outlet and are currently not being considered for publication elsewhere. </li>
                               
                <li>The manuscript should normally conform to the style of the 7th edition of the Publication Manual
                of the American Psychological Association (APA).</li>
                <li>It should not exceed a maximum of 12 pages, inclusive of the title page and the references list. It
should include a cover page containing the title of the manuscript, the name(s), affiliation(s), phone
numbers, and e-mail addresses of the author(s). </li> 
                <li>An Abstract of between 150 to 200 words (single-line spacing) should follow the title closely on
                this page and should be followed by three to five keywords for indexing purposes.      </li>
                
                <li>Tables and figures should be marked with Arabic numerals and should not have vertical lines. All
                figures, diagrams, and charts should be presented in compliance with 7th edition APA styles. </li>
                <li>The soft copy of the article prepared in Microsoft Word should be sent to the Managing Editor via
                email at fujrepac@fudutsinma.edu.ng or fujrepac@gmail.com </li>
                <li>Submission of an article is to be accompanied by a non-refundable assessment fee of five Thousand
Naira (N5,000.00) or the equivalence in the currency of your country payable to: Bank: United
Bank for Africa (UBA), Account Name: Fudma Journal of Research, Educational Psychology and
Counselling; Account No: 2311581782 (Note: A copy of the proof of payment should also be sent
to the above email address); </li> 
                <li>Author(s) whose articles are accepted for publication will be requested to pay publication fee of
                twenty thousand naira (N20, 000.00) or the equivalence in the currency of your country. </li>
                
                                
                
</p></ol> 
         </article>
        <!-- this is aside  -->
        <aside>
           
        <div class="app-wrapper">
	    
	    <div class="app-content pt-3 p-md-3 p-lg-4">
		    <div class="container-xl">			    
			    <h2 class="app-page-title">Authorized Access Only</h2>
			    <hr class="mb-4">
                <div class="row g-4 settings-section">
	                <div class="col-12 col-md-12">
		                <div class="app-card app-card-settings shadow-sm p-4">  
						    
						    <div class="app-card-body">
							    <form class="settings-form" action="" method="post">
                                
                                        <div class="mb-3">
									    <label for="setting-input-3" class="form-label" style="float:left;">Email Address</label>
									    <input type="email" class="form-control" id="setting-input-3" name="email" placeholder="" required>
										</div>
                                       
                                        <div class="mb-3">
									    <label for="setting-input-3" class="form-label" style="float:left;"> Password </label>
									    <input type="password" class="form-control" id="setting-input-3" name="password" placeholder="" required>
										</div>
										<button type="submit" class="btn app-btn-primary" style="background-color:rgb(173, 7, 7); color: hwb(0 100% 0%);" name="signnap" >Login</button>
                                        <p style="color:">Don't have an account? Contact <a href="contact"> Admin</a><p>
 
                            </form>
						    </div><!--//app-card-body-->
						    
						</div><!--//app-card-->
	                </div>
                </div><!--//row-->
                <hr class="my-4">
		    </div><!--//container-fluid-->
	    </div><!--//app-content-->
	    
       
        </aside>
        
                <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
  <?php 
 ?>    

        </body>
        <!-- footer starts here -->
        <footer class="myfooter">
 <?php 
        include_once('includes/footer.php');
 ?>
        </footer>
        
</html>
<?php 
        include_once('Db_Connect.php');
?>
<html>
    <head>
    <title>Fudma Journal of Research, Educational Psychology and Counselling</title>
    <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta content="" name="description">
  <meta content="" name="keywords">
  <!-- Favicons -->
  <link href="assets/img/logg.jpg" rel="icon">
  <link href="assets/img/logg.jpg" rel="apple-touch-icon">
  <!-- 410Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <!-- sweetAleart here -->
  <script src="https://cdn.bootcss.com/jquery/3.3.1/jquery.js"></script>
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
  <link href="css/web_style.css" rel="stylesheet">

    </head>
    <div>
    <header>
        
    <img src="assets/img/flo.jpg" width="8%" height="8%" style="float: left; magin-bottom:20px; border-radius: 50%;">  
    <img src="includes/img/logg.jpg" width="8%" height="8%" style="float: right; margin-bottom:20px; border-radius: 50%;"> 
    <b> FEDERAL UNIVERSITY DUTSINMA KATSINA STATE NIGERIA </b> <br>
    <b style="color: white; font-size: 16px;">DEPARTMENT OF EDUCATIONAL PSYCHOLOGY AND COUNSELLING</b>
    <!-- <h3>Jounal of Educational Management</h3> -->
    </div>
</header>
    <div>
         <nav id="navbar" class="navbar">
             <!-- style="background-color: wheat; margin-right: px; width: 100%; color: #000436; text-align: center;"> -->
            <!-- <ul class="nav nav-pills"> rgb(175, 124, 28) nav bar bg-->
                <b><ul>
                <li class="nav-item"><a class="nav-link" href="index">HOME</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="about">ABOUT</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="issues">CURRENT ISSUES</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="archives">ARCHIVES</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="submission">SUBMISSION</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="editors">EDITORIAL BOARD</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="announcement">ANNOUNCEMENT</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="contact">CONTACT US</a>
                </li>
            </ul></b>
            <i class="bi bi-list mobile-nav-toggle"></i>
     </nav>
    </div>
    </header><!-- End Header -->
    <!-- new navbar testing -->
   
    <body>
 <!-- Vendor JS Files -->
 <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
    </body>
</html>
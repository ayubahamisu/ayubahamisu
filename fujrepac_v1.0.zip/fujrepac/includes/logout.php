<?php
include_once('includes/Db_Connect.php');
	session_start();
	session_destroy();

	header('location:../login');
?>
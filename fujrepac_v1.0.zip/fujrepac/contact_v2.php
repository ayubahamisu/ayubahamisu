<?php 
            include_once('includes/Db_Connect.php');
        ?>
<!DOCTYPE html>
<html>
    <head>
        <title>Fudma Journal of Research, Educational Psychology and Counselling</title>
        <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
   <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/logg.jpg" rel="icon">
  <link href="assets/img/logg.jpg" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="css/web_style.css" rel="stylesheet">
  <!-- sweetAleart here -->
  <script src="https://cdn.bootcss.com/jquery/3.3.1/jquery.js"></script>
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
  <link rel="stylesheet" href="css/web_style.css">
       
    </head><body class="">
        <!-- main header of the page  -->
        <!-- <header> -->
            
            <?php 
                    include_once('includes/cont.php');
            ?>
        <!-- </header> -->
            <!-- navigation links  -->
       
            <!-- section starts from here  -->
        <section class="calline">
                 A PUBLICATION OF FUJREPAC 2024
        </section>
        <!-- journal article section     -->
        <article>
            
       <center> <h2 style="font-size: 16px;">CONTACT PAGE</h2></center><br>
        <p align="justify">
            FUDMA Journal of Educational Management (FUDMAJEM) is an annual Journal Published
         by the Department of Educational Administration and Planning, Federal University Dutsin-Ma, Katsina State, Nigeria.
        The goal of the Journal is to promote research in the field of Educational Management.
     </p> 

 <h2 align="center">Enquiries To: </h2>
       <p align="justify">
          
Dr. A. A. Bagudu 
Editor-in-Chief (08033802836)
Dr. S. Abubakar
Managing Editor (07032039199)
FDepartment of Educational Psychology and Counselling,
Faculty of Education, Federal University Dutsin-Ma,
P. M. B. 5001, Dutsin-Ma, Katsina State, Nigeria.
fujrepac@fudutsinma.edu.ng or fujrepac@gmail.com  
 </p> 
</article>
        <!-- this is aside  -->
        <aside>
           
      
        </aside>
        
       
                <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

        </body>
        <!-- footer starts here -->
        <footer class="myfooter">
 <?php 
        include_once('includes/footer.php');
 ?>
        </footer>
        
</html>

<!DOCTYPE html>
<html>
    <head>
        <title>Fudma Journal of Research, Educational Psychology and Counselling</title>
        <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
   <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/logg.jpg" rel="icon">
  <link href="assets/img/logg.jpg" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <link href="css/web_style.css" rel="stylesheet">
  <!-- sweetAleart here -->
  <script src="https://cdn.bootcss.com/jquery/3.3.1/jquery.js"></script>
  <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">
  <link rel="stylesheet" href="css/web_style.css">
           
    </head>
        <!-- main header of the page  -->
        <!-- <header> -->
        <body class="body">
<?php 
    include_once('includes/Db_Connect.php');
?>
              
            <?php 
                    include_once('includes/announce.php');
            ?>
        <!-- </header> -->
            <!-- navigation links  -->
       
            <!-- section starts from here  -->
        <section class="calline">
             <!-- style="background-color: rgb(173, 7, 7); padding: 2px; color: white; text-align: center;font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', 'Geneva', Verdana, sans-serif; font-size: 14px;"> -->
                A PUBLICATION OF FUJREPAC 2024
        </section>
        <!-- journal article section     -->
        <article>
             <!-- style="background-color: white; height: 100%; padding:; width: 70%; font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', 'Geneva', Verdana, sans-serif; font-size: 14px; border-radius: 6px, 8px, 12px solid black; clear: both;"> -->
       <center> <h2 style="font-size: 16px;"><b>IMPORTANT NOTICE TO CONTRIBUTORS</b></h2></center><br>
        <p align="justify">No part of this publication may be reproduced, stored or transmitted or disseminated in any
form or by any means without prior written permission from the Department of Educational
Psychology and Counselling, Federal University, Dutsin-Ma, Nigeria. Consent is hereby
given to the contributors to copy their own articles from the Journal for any scholarly or
academic purpose of their own. </p>  
        
       


        </article>
        <!-- this is aside  -->
        <aside>
        <center><h5>DISCLAIMER</h5> </center>
       <p align="justify">
          <div>Every Author is solely responsible for the views and styles expressed in the articles
published in this Journal. The views are not necessarily shared by reviewers, the Editorial Board,
Editorial Advisory Board, the Department of Educational Psychology and Counselling and Federal
University Dutsin-Ma, Katsina State.</div> </p>

<h5>All Right Reserve</h5>
       <marquee> <p align="justify">No part of this publication may be reproduced, stored or transmitted or disseminated in any
form or by any means without prior written permission from the Department of Educational
Psychology and Counselling, Federal University, Dutsin-Ma, Nigeria. Consent is hereby
given to the contributors to copy their own articles from the Journal for any scholarly or
academic purpose of their own.</p></marquee>
 <center><div class="contena">

 Research for Human and National Development
 </div>  </center> 
        </aside>
       
                <!-- Vendor JS Files -->
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

        </body>
        <!-- footer starts here -->
        <footer class="myfooter">
 <?php 
        include_once('includes/footer.php')
 ?>
        </footer>
        
</html>